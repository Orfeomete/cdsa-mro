"""Independent readback; no training, no environments, no checkpoint selection."""
from pathlib import Path
import os,sys,json,hashlib,math,csv
for n in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[n]='1'
W=Path(__file__).parent
sys.path.insert(0,r'C:\Users\Mete\AppData\Local\Temp\limulus_v74_ppo_runtime')
import numpy as np
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,j):
 with Path(p).open('x',encoding='utf8') as f:json.dump(j,f,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def auc_rank(y,score):
 pos=y.astype(bool);n=int(pos.sum());m=len(y)-n
 if n==0 or m==0:return None
 order=np.argsort(score,kind='stable');rank=np.zeros(len(y),float);start=0
 while start<len(order):
  end=start+1
  while end<len(order) and score[order[end]]==score[order[start]]:end+=1
  rank[order[start:end]]=(start+1+end)/2;start=end
 return float((rank[pos].sum()-n*(n+1)/2)/(n*m))
def metrics(y,P):
 k=P.shape[1];pred=P.argmax(axis=1);cm=np.zeros((k,k),dtype=int)
 for a,b in zip(y,pred):cm[int(a),int(b)]+=1
 supported=np.flatnonzero(cm.sum(axis=1)>0);per=[]
 for c in range(k):
  tp=int(cm[c,c]);fp=int(cm[:,c].sum()-tp);fn=int(cm[c,:].sum()-tp)
  auc=auc_rank(y==c,P[:,c]);precision=tp/(tp+fp) if tp+fp else 0.;recall=tp/(tp+fn) if tp+fn else 0.;f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.
  per.append(dict(class_id=c,support=int(cm[c].sum()),predictions=int(cm[:,c].sum()),precision=precision,recall=recall,F1=f1,AUC=auc))
 out=dict(accuracy=float(np.trace(cm)/cm.sum()),precision_macro=float(np.mean([per[i]['precision'] for i in supported])),recall_macro=float(np.mean([per[i]['recall'] for i in supported])),F1_macro=float(np.mean([per[i]['F1'] for i in supported])),AUC_macro_OvR=float(np.mean([r['AUC'] for r in per if r['AUC'] is not None])),NLL=math.fsum(-math.log(max(float(P[i,c]),1e-15)) for i,c in enumerate(y))/len(y),supported_classes=supported.tolist(),confusion_matrix=cm.tolist(),per_class=per)
 return out
def forward(z,X):
 h=np.tanh(np.dot(X,z['W1'].T)+z['b1']);s=np.dot(h,z['Wa'].T)+z['ba'];s-=np.max(s,axis=1)[:,None];e=np.exp(s);return e/np.sum(e,axis=1)[:,None]
def main():
 finish=read(W/'EXIT.json');assert finish['stage']=='BOUNDED_STUDY_FINISHED' and finish['models']==30
 protocol=read(W/'PROTOCOL.json');frozen=read(W/'ALL_TRAINING_FROZEN_BEFORE_TEST.json');split=read(W/'SPLIT_INTEGRITY_BEFORE_FIRST_OPTIMIZER.json')
 checks=dict(models_finished_30=len(frozen['completed_jobs'])==30,checkpoint_bytes_preserved_270=len(frozen['checkpoint_SHA256'])==270 and all(sha(W/p)==h for p,h in frozen['checkpoint_SHA256'].items()),unchanged_source_snapshots=all(sha(r['source'])==r['SHA256']==sha(r['snapshot']) for r in protocol['sources']),prospective_plan_source_byte_guard=sha(W/'experiment.py')==protocol['engine_SHA256'],all_training_fixed_before_test=frozen['test_forward_calls_so_far']==0,finite_probability_sums=True,all_checkpoint_forwards_match_saved_test=True,all_validation_values_match_independent_forward=True,TensorBoard_matches_saved_scalars=True,AUC_pairwise_equals_midrank=True,confusion_matrix_counts_match=True,no_split_record_overlap=True,MRO_family_disjoint=True,fixed_training_budget=True)
 datasets={d:np.load(W/'INPUTS'/(d+'_DATA.npz')) for d in protocol['domains']};rows=[];rawcurves=[];event_scalars=0;max_tb_error=0.;max_val_error=0.
 group=read(W/'INPUTS/MRO_GROUP_SPLIT.json');groups=[set(v) for v in group['families'].values()];checks['MRO_family_disjoint']=all(not(groups[i]&groups[j]) for i in range(3) for j in range(i))
 for domain in protocol['domains']:
  dat=datasets[domain];sets={role:{hashlib.sha256(r.tobytes()).hexdigest() for r in dat[role+'_X']} for role in ['train','validation','test']}
  checks['no_split_record_overlap']&=all(not(sets[a]&sets[b]) for a,b in [('train','validation'),('train','test'),('validation','test')])
 for job in frozen['completed_jobs']:
  folder=W/'RUNS'/job;train=read(folder/'TRAINING.json');test=read(folder/'TEST_CURVE.json');domain=train['domain'];dat=datasets[domain]
  checks['fixed_training_budget']&=train['rounds']==32 and train['optimizer_calls']==576 and train['training_decisions']==55296
  checks['all_training_fixed_before_test']&=test['test_after_all_training'] and test['utc']>=frozen['utc'] and not train['test_used']
  for record in train['curve']:
   rnd=record['round']
   with np.load(folder/f'checkpoint_{rnd:02d}.npz') as z:
    P=forward(z,dat['validation_X']);y=dat['validation_y'];nll=math.fsum(-math.log(max(float(P[i,c]),1e-15)) for i,c in enumerate(y))/len(y)
    error=abs(nll-record['values']['validation/reference_action_cross_entropy']);max_val_error=max(max_val_error,error)
    checks['all_validation_values_match_independent_forward']&=error<1e-12
    pt=forward(z,dat['test_X']);record_test=next(r for r in test['curve'] if r['round']==rnd)
    checks['all_checkpoint_forwards_match_saved_test']&=abs(float(np.mean(pt.argmax(axis=1)==dat['test_y']))-record_test['accuracy'])<1e-14
    if rnd==32:
     saved=np.load(folder/'FINAL_TEST_SCORES.npz');checks['all_checkpoint_forwards_match_saved_test']&=np.array_equal(saved['y'],dat['test_y']) and np.max(np.abs(saved['probabilities']-pt))<1e-13
   rawcurves.append(dict(job=job,domain=domain,method=train['method'],seed=train['seed'],round=rnd,validation_NLL=record['values']['validation/reference_action_cross_entropy'],training_NLL=record['values']['train/reference_action_cross_entropy'],validation_accuracy=record['values']['validation/accuracy'],test_accuracy=record_test['accuracy']))
  P=saved['probabilities'];y=saved['y'];checks['finite_probability_sums']&=np.isfinite(P).all().item() and np.max(np.abs(P.sum(axis=1)-1))<1e-12 and bool((P>=0).all())
  result=metrics(y,P);checks['confusion_matrix_counts_match']&=sum(sum(x) for x in result['confusion_matrix'])==len(y)
  for c in result['per_class']:
   if c['AUC'] is None:continue
   positive=P[y==c['class_id'],c['class_id']];negative=P[y!=c['class_id'],c['class_id']]
   pair=float(((positive[:,None]>negative[None,:]).sum()+.5*(positive[:,None]==negative[None,:]).sum())/(len(positive)*len(negative)))
   checks['AUC_pairwise_equals_midrank']&=abs(pair-c['AUC'])<1e-14
  rows.append(dict(job=job,domain=domain,method=train['method'],seed=train['seed'],n_test=len(y),**result))
  # Read the real event files back; they contain float32 TensorBoard scalars.
  for suffix,records in [('',train['curve']),('_posttraining_test',test['curve'])]:
   ea=EventAccumulator(str(W/'TENSORBOARD'/(job+suffix)),size_guidance={'scalars':0});ea.Reload()
   for tag in ea.Tags()['scalars']:
    events=ea.Scalars(tag);checks['TensorBoard_matches_saved_scalars']&=[e.step for e in events]==[r['round'] for r in records if suffix or tag in r['values']]
    for e in events:
     rr=next(r for r in records if r['round']==e.step)
     expect=rr['accuracy'] if tag=='test_posttraining/accuracy' else rr['NLL'] if tag=='test_posttraining/reference_action_cross_entropy' else rr['values'][tag]
     err=abs(expect-e.value);max_tb_error=max(max_tb_error,err);checks['TensorBoard_matches_saved_scalars']&=err<2e-6*(1+abs(expect));event_scalars+=1
 groups=[]
 for domain in protocol['domains']:
  for method in protocol['methods']:
   group=[r for r in rows if r['domain']==domain and r['method']==method];summary=dict(domain=domain,method=method,n_model_seeds=5,n_test_per_seed=group[0]['n_test'])
   for field in ['accuracy','precision_macro','recall_macro','F1_macro','AUC_macro_OvR','NLL']:
    a=np.array([r[field] for r in group]);summary[field]=dict(mean=float(a.mean()),SD=float(a.std(ddof=1)))
   curve=[]
   for rnd in protocol['curve_rounds']:
    groupc=[r for r in rawcurves if r['domain']==domain and r['method']==method and r['round']==rnd];point=dict(round=rnd)
    for field in ['validation_NLL','training_NLL','validation_accuracy','test_accuracy']:
     a=np.array([r[field] for r in groupc]);point[field]=dict(mean=float(a.mean()),SD=float(a.std(ddof=1)))
    curve.append(point)
   summary['curve']=curve;groups.append(summary)
 checks={k:bool(v) for k,v in checks.items()};assert all(checks.values()),checks
 write(W/'INDEPENDENT_VALIDATION.json',dict(passed=True,checks=checks,models=30,checkpoints=270,scalar_records_read=event_scalars,max_TensorBoard_float32_error=max_tb_error,max_independent_validation_NLL_error=max_val_error,retraining=0,checkpoint_reselection=0))
 write(W/'RESULTS_AND_METRICS.json',dict(protocol=protocol['id'],new_study_date='2026-10-18',old_results_not_replaced=True,groups=groups,models=rows,split=split['domains'],MRO_unseen_test_class_1_support=1,MRO_test_is_not_external_validation=True))
 for name,rs in [('FINAL_MODEL_METRICS.csv',rows),('LEARNING_CURVES.csv',rawcurves)]:
  flat=[{k:v for k,v in r.items() if not isinstance(v,(dict,list))} for r in rs]
  with (W/name).open('x',encoding='utf8',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
 print('Independent readback passed',checks,'scalars',event_scalars,flush=True)
 for g in groups:print(g['domain'],g['method'],'accuracy',g['accuracy'],'F1',g['F1_macro'],'AUC',g['AUC_macro_OvR'],flush=True)
if __name__=='__main__':main()
