from pathlib import Path
import json,math,subprocess
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor,Color
from PIL import Image
W=Path(__file__).parent
F=W/'FIGURES';F.mkdir(exist_ok=True)
R=json.loads((W/'RESULTS_AND_METRICS.json').read_text(encoding='utf8'))
DEP=Path(r'C:\Users\Mete\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library')
pdfmetrics.registerFont(TTFont('DejaVu',str(DEP/'share/fonts/DejaVuSans.ttf')))
for lang in ['EN','TR']:
 for field,stem in [('validation_NLL','validation_loss'),('test_accuracy','test_accuracy')]:
  out=F/f'{stem}_{lang}';c=canvas.Canvas(str(out.with_suffix('.pdf')),pagesize=(456,414));c.setFont('DejaVu',8)
  for j,domain in enumerate(['BB3','MRO','ATM']):
   x0=61;y0=293-j*125;ww=374;hh=82
   gs=[g for g in R['groups'] if g['domain']==domain]
   hi=max(p[field]['mean']+p[field]['SD'] for g in gs for p in g['curve'])
   hi=1. if field=='test_accuracy' else math.ceil(hi*2)/2
   def xy(r,v):return x0+r/32*ww,y0+max(0,min(hi,v))/hi*hh
   c.setFillColor(HexColor('#2C3E50'));c.drawString(x0,y0+hh+12,domain)
   for t in range(5):
    y=y0+hh*t/4;c.setStrokeColor(HexColor('#D9D9D9'));c.setLineWidth(.4);c.line(x0,y,x0+ww,y)
    c.drawRightString(x0-6,y-3,f'{hi*t/4:.2f}' if field=='test_accuracy' else f'{hi*t/4:.1f}')
   for r in [0,8,16,24,32]:
    x=x0+r/32*ww;c.drawCentredString(x,y0-13,str(r))
   c.setStrokeColor(HexColor('#34495E'));c.line(x0,y0,x0+ww,y0);c.line(x0,y0,x0,y0+hh)
   for g,col in zip(gs,['#1F4E79','#C0392B']):
    pts=g['curve'];p=c.beginPath();a=xy(pts[0]['round'],pts[0][field]['mean']+pts[0][field]['SD']);p.moveTo(*a)
    for z in pts[1:]:p.lineTo(*xy(z['round'],z[field]['mean']+z[field]['SD']))
    for z in reversed(pts):p.lineTo(*xy(z['round'],z[field]['mean']-z[field]['SD']))
    p.close();c.saveState();c.setFillColor(HexColor(col));c.setFillAlpha(.13);c.drawPath(p,stroke=0,fill=1);c.restoreState()
    p=c.beginPath();p.moveTo(*xy(pts[0]['round'],pts[0][field]['mean']))
    for z in pts[1:]:p.lineTo(*xy(z['round'],z[field]['mean']))
    c.setStrokeColor(HexColor(col));c.setLineWidth(1.5);c.drawPath(p)
   c.setFillColor(HexColor('#2C3E50'));c.saveState();c.translate(16,y0+hh/2);c.rotate(90)
   label=('Validation cross entropy' if lang=='EN' else 'Doğrulama çapraz entropisi') if field=='validation_NLL' else ('Test accuracy' if lang=='EN' else 'Test doğruluğu')
   c.drawCentredString(0,0,label);c.restoreState()
  c.setFillColor(HexColor('#2C3E50'));c.drawCentredString(248,14,'Training round' if lang=='EN' else 'Eğitim turu')
  for x,col,text in [(75,'#1F4E79','Central PPO' if lang=='EN' else 'Merkezî PPO'),(245,'#C0392B','FedAvg PPO')]:
   c.setStrokeColor(HexColor(col));c.setLineWidth(1.6);c.line(x,400,x+20,400);c.setFillColor(HexColor('#2C3E50'));c.drawString(x+26,397,text)
  c.showPage();c.save()
  subprocess.run([str(DEP/'bin/pdftoppm.exe'),'-png','-r','300','-singlefile',str(out.with_suffix('.pdf')),str(out)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  with Image.open(out.with_suffix('.png')) as im:im.save(out.with_suffix('.tif'),compression='tiff_lzw',dpi=(300,300))
print('Four plotted figures saved as PNG and 300 dpi TIFF')
