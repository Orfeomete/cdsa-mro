CDSA validation diagnostic study dated 18 October 2026

This is a NEW internal synthetic diagnostic study for the thesis and Article A.
It does not reconstruct historical validation-loss logs, change the old preregistered
decision rule, establish operational validity or replace the older experiment archives.

30 models completed, 3 tasks, 2 PPO arms, 5 model seeds, 32 fixed rounds.
270 checkpoints were frozen before any test forward pass. 1,860 TensorBoard scalars
were read back independently. Final test metrics and complete per-class supports,
confusion matrices and probabilities are retained. Validation loss is unweighted
reference-action negative log probability, not the PPO optimisation objective.

The curves have NOT been selected to show improvement. Final mean validation loss
exceeds its initial value in all six task/arm combinations. The MRO test has one
class-1 record unseen in training, and no class-0 support. Its supported-class macro
AUC is not an external-validation claim. Seed SD uses the same fixed test pool.

PROTOCOL.json and INPUTS identify exact source snapshots, dataset roles and runtime.
RUNS contains the saved parameters, training traces and post-training test scores.
TENSORBOARD contains genuine event records and can be opened with TensorBoard using
this folder as logdir. The posttraining_test directories were written after every
training model had finished. Graphs were plotted from the double-precision JSON/CSV
values also verified against TensorBoard float32 scalar values.

This package contains experiment.py and analyse_and_verify.py as the frozen local
record, not an installer for a new runtime. Reproduction requires the Python/NumPy
and TensorBoard versions recorded in PROTOCOL.json and DEPENDENCIES.json. The local engine records the
original workstation source locations and refuses to overwrite existing run folders.
Do not rerun it over this evidence directory. To reproduce elsewhere, use the supplied
INPUTS source snapshots and data in a fresh output directory, documenting path-only
adaptations separately. No new public DOI is claimed and historical GitHub/Zenodo
releases do not yet contain this addition.
