"""Prospective bounded diagnostic study; frozen historic studies are read-only."""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone
import os,sys,json,hashlib,ast,importlib.util,time,ctypes,csv,math
W=Path(__file__).parent;K=W.parents[1]
os.environ.update({n:'1' for n in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']})
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
RT=Path(r'C:\Users\Mete\AppData\Local\Temp\limulus_v74_ppo_runtime');sys.path.insert(0,str(RT))
import numpy as np
from tensorboard.compat.proto.event_pb2 import Event
from tensorboard.compat.proto.summary_pb2 import Summary
from tensorboard.summary.writer.record_writer import RecordWriter
utc=lambda:datetime.now(timezone.utc).isoformat()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,obj,mutable=False):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w' if mutable else 'x',encoding='utf8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def priority():
 kernel=ctypes.windll.kernel32;kernel.GetCurrentProcess.restype=ctypes.c_void_p;kernel.SetPriorityClass.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
 assert kernel.SetPriorityClass(kernel.GetCurrentProcess(),0x4000)
def resources():
 from ctypes import wintypes as T
 kernel=ctypes.windll.kernel32
 def times():
  a,b,c=[T.FILETIME() for _ in range(3)];assert kernel.GetSystemTimes(ctypes.byref(a),ctypes.byref(b),ctypes.byref(c));return [(x.dwHighDateTime<<32)+x.dwLowDateTime for x in [a,b,c]]
 values=[]
 for _ in range(2):
  a=times();time.sleep(2);b=times();values.append(100*(1-(b[0]-a[0])/((b[1]-a[1])+(b[2]-a[2]))))
 class Mem(ctypes.Structure):_fields_=[('length',T.DWORD),('load',T.DWORD)]+[(n,ctypes.c_ulonglong) for n in ['total','avail','page','pageavail','virtual','virtualavail','extended']]
 m=Mem();m.length=ctypes.sizeof(m);assert kernel.GlobalMemoryStatusEx(ctypes.byref(m));free=m.avail/2**30
 return dict(utc=utc(),CPU_samples_percent=values,logical_processors=os.cpu_count(),available_memory_GiB=free,gate_passed=free>=6 and max(values)<=65 and os.cpu_count()>=12)
def configure(domain):
 root=W/'INPUTS/SOURCE'/domain
 env=load('study_env_'+domain,root/'env.py')
 agent=load('study_agent_'+domain,root/'agent.py')
 fed=load('study_fed_'+domain,root/'fedavg.py')
 namespace=dict(np=np,PPOActorCritic=agent.PPOActorCritic)
 namespace.update(vars(env))
 config=ast.parse((root/'config.py').read_text(encoding='utf8'))
 # Reuse exact constructor functions and constants, with the frozen data path.
 wanted=[]
 for n in config.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):wanted.append(n)
  elif isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['PILLAR','N_ACTIONS','STATE_DIM','NEW_STEP_API','INFO_TRUE_KEY','ACTION_LABELS','_CLIENT_EXPONENTS','_CLIENT_CYBER_RATES'] for t in n.targets):wanted.append(n)
 namespace['_DATA']=str(W/'INPUTS/mro_incidents.json')
 exec(compile(ast.Module(body=wanted,type_ignores=[]),str(root/'config.py'),'exec'),namespace)
 staged=ast.parse((root/'staged.py').read_text(encoding='utf8'))
 wanted=[n for n in staged.body if isinstance(n,ast.FunctionDef) and n.name in ['new_agent','env_reset','env_step','train_local']]
 namespace.update(LOCAL_ROLLOUTS=6,ROLLOUT_LEN=96)
 exec(compile(ast.Module(body=wanted,type_ignores=[]),str(root/'staged.py'),'exec'),namespace)
 return SimpleNamespace(**namespace),fed.FedAvgAggregator
def prepare():
 assert not (W/'PROTOCOL.json').exists()
 sources=[]
 for domain in ['BB3','MRO','ATM']:
  repo=K/('CDSA-'+domain)/'12_GitHub_Repo'/('cdsa-'+domain.lower())
  paths={'config.py':repo/'experiments/faz_a_config.py','staged.py':repo/'experiments/faz_a_staged.py','agent.py':repo/'src/rl_agents/ppo_actor_critic.py','fedavg.py':repo/'src/federated/fedavg.py','env.py':repo/('src/rl_environment/'+{'BB3':'pilot_state_env.py','MRO':'cdsa_mro_env.py','ATM':'env.py'}[domain])}
  for name,source in paths.items():
   dest=W/'INPUTS/SOURCE'/domain/name;dest.parent.mkdir(parents=True,exist_ok=True)
   with dest.open('xb') as f:f.write(source.read_bytes())
   sources.append(dict(source=str(source),snapshot=str(dest),SHA256=sha(source)))
 source=K/'CDSA-MRO/12_GitHub_Repo/cdsa-mro/data/synthetic_incidents_v1.json';dest=W/'INPUTS/mro_incidents.json'
 with dest.open('xb') as f:f.write(source.read_bytes())
 sources.append(dict(source=str(source),snapshot=str(dest),SHA256=sha(source)))
 protocol=dict(id='CDSA-VAL-DIAGNOSTIC-20261018-R1',created_utc=utc(),prospective_local_plan_not_independently_registered=True,authority='Mete explicitly authorized the bounded thesis and Article A validation-curve study on18October2026',domains=['BB3','MRO','ATM'],model_seeds=[24101,24102,24103,24104,24105],methods=['central_PPO','FedAvg_PPO'],rounds=32,clients=3,local_rollouts=6,rollout_length=96,epochs_per_update=2,decisions_per_model=32*3*6*96,curve_rounds=list(range(0,33,4)),model=dict(hidden=64,lr=.05,reward_scale=.05,gamma=.99,GAE_lambda=.95,clip_epsilon=.2),validation_loss='unweighted negative log probability of synthetic reference action, natural log, probability floor1e-15; not the PPO actor-critic optimization objective',training_loss='original PPO clipped surrogate plus critic loss returned by unchanged update',selection='fixed final round32; no early stopping or hyperparameter/checkpoint selection',test_curve='evaluated only after every model has finished, from frozen checkpoints; no test feedback to training',new_test_is_external_or_blind=False,test_scope='new internal synthetic split; not operational validation; MRO uses the pre-existing source corpus',BB3_ATM_pools=dict(train=3000,validation=900,test=1800,seeds=dict(train=2301000000,validation=2302000000,test=2303000000),domain_offset=dict(BB3=10000,ATM=30000)),MRO_split=dict(group='olay_ozeti.olay_turu',seed=2304000000,train_families=9,validation_families=3,test_families=3,allocation='sort family names, one frozen NumPy permutation; no outcome-driven reassignment'),metrics='accuracy; precision/recall/F1 macro over classes with positive test support, absent prediction contributes0; per-class one-v-rest AUC with midrank ties and positive/negative support; supported-class macro AUC; full fixed-action confusion matrix',uncertainty='mean and sample standard deviation across five model seeds on the same test pool; not independent test datasets',old_results_or_preregistration_changed=False,new_human_coding=False,scientific_scope='diagnostic learning trajectories; no method superiority, causal generalization, or mission acceptance',capacity_gate='at least6GiB free, two CPU samples at most65percent, at least12logical CPUs; one BelowNormal process/one numeric thread/no child workers',wall_limit_seconds=3600,sources=sources,engine_SHA256=sha(__file__),runtime=dict(python=sys.version,numpy=np.__version__,numpy_path=np.__file__,tensorboard_runtime=str(RT)))
 put(W/'PROTOCOL.json',protocol)
 print('Prospective protocol frozen; no optimizer or experiment executed',flush=True)
def filter_mro(env,indices):
 env.dataset=[env.dataset[int(i)] for i in indices];env.features=env.features[indices].copy();env.labels=env.labels[indices].copy();env.current_idx=0
 return env
def pools(C,domain):
 if domain=='MRO':
  env=C.make_env(2304000001);families=np.array([x['olay_ozeti']['olay_turu'] for x in env.dataset]);names=np.array(sorted(set(families)))
  assert len(names)==15
  order=np.random.default_rng(2304000000).permutation(names);groups=dict(train=order[:9],validation=order[9:12],test=order[12:])
  out={};index={}
  for key,g in groups.items():
   ids=np.flatnonzero(np.isin(families,g));index[key]=ids
   out[key]=(env.features[ids].astype(float),env.labels[ids].copy())
  put(W/'INPUTS/MRO_GROUP_SPLIT.json',dict(families={k:v.tolist() for k,v in groups.items()},indices={k:v.tolist() for k,v in index.items()},disjoint=True))
  return out,index
 offset={'BB3':10000,'ATM':30000}[domain];out={}
 for name,n,base in [('train',3000,2301000000),('validation',900,2302000000),('test',1800,2303000000)]:
  env=C.make_env(base+offset);s=C.env_reset(env,base+offset);X=[];y=[]
  for _ in range(n):
   X.append(np.asarray(s,dtype=float).copy());s2,_,done,info=C.env_step(env,0);y.append(info[C.INFO_TRUE_KEY]);s=C.env_reset(env) if done else s2
  out[name]=(np.array(X),np.array(y,dtype=int))
 return out,None
def probs(agent,X):
 h=np.tanh(X@agent.W1.T+agent.b1);z=h@agent.Wa.T+agent.ba;z-=z.max(axis=1,keepdims=True);v=np.exp(z);return v/v.sum(axis=1,keepdims=True)
def scores(y,p):
 return dict(NLL=float(-np.log(np.maximum(p[np.arange(len(y)),y],1e-15)).mean()),accuracy=float(np.mean(p.argmax(axis=1)==y)))
class Events:
 def __init__(self,path):
  path.mkdir(parents=True,exist_ok=True);self.file=(path/f'events.out.tfevents.{int(time.time())}.{os.getpid()}').open('xb');self.writer=RecordWriter(self.file)
  self.writer.write(Event(wall_time=time.time(),file_version='brain.Event:2').SerializeToString())
 def add(self,step,values):
  event=Event(wall_time=time.time(),step=step,summary=Summary(value=[Summary.Value(tag=k,simple_value=float(v)) for k,v in values.items()]));self.writer.write(event.SerializeToString());self.writer.flush()
 def close(self):self.writer.close()
def production():
 priority();p=read(W/'PROTOCOL.json');assert p['engine_SHA256']==sha(__file__)
 assert all(sha(x['source'])==x['SHA256']==sha(x['snapshot']) for x in p['sources'])
 put(W/'START.json',dict(utc=utc(),pid=os.getpid(),priority='BELOW_NORMAL',numeric_threads=1,extra_workers=0,protocol_SHA256=sha(W/'PROTOCOL.json')))
 begin=time.monotonic();caps=[]
 while True:
  cap=resources();caps.append(cap);put(W/'CAPACITY_HISTORY.json',caps,True)
  if cap['gate_passed']:break
  put(W/'LIVE.json',dict(utc=utc(),stage='WAITING_CAPACITY',running=True,new_optimizers=0,resources=cap),True)
  if time.monotonic()-begin>1200:put(W/'EXIT.json',dict(stage='WAIT_LIMIT_NO_TRAINING',exit_code=0));return
  time.sleep(60)
 put(W/'CAPACITY_ADMISSION.json',cap)
 data={};configs={};aggregators={};indices={};integrity=[]
 for domain in p['domains']:
  C,Fed=configure(domain);configs[domain]=C;aggregators[domain]=Fed;data[domain],indices[domain]=pools(C,domain)
  hashes={k:{hashlib.sha256(x.astype('<f8').tobytes()).hexdigest() for x in X} for k,(X,y) in data[domain].items()}
  assert not (hashes['train']&hashes['validation'] or hashes['train']&hashes['test'] or hashes['validation']&hashes['test'])
  np.savez_compressed(W/'INPUTS'/(domain+'_DATA.npz'),**{key+'_'+v:arr for key,(X,y) in data[domain].items() for v,arr in [('X',X),('y',y)]})
  integrity.append(dict(domain=domain,counts={k:len(X) for k,(X,y) in data[domain].items()},classes={k:np.bincount(y,minlength=C.N_ACTIONS).tolist() for k,(X,y) in data[domain].items()},zero_cross_split_identical_rows=True,dataset_SHA256=sha(W/'INPUTS'/(domain+'_DATA.npz'))))
 put(W/'SPLIT_INTEGRITY_BEFORE_FIRST_OPTIMIZER.json',dict(passed=True,utc=utc(),domains=integrity,no_optimizer_yet=True))
 alljobs=[]
 for domain in p['domains']:
  C=configs[domain];Fed=aggregators[domain]
  for seed in p['model_seeds']:
   for method in p['methods']:
    assert time.monotonic()-begin<p['wall_limit_seconds'],'Bounded study wall limit reached; no automatic rerun'
    cap=resources()
    if not cap['gate_passed']:put(W/'PAUSED_CAPACITY.json',dict(utc=utc(),completed=alljobs,resources=cap));return
    job=f'{domain}_{method}_{seed}';folder=W/'RUNS'/job;folder.mkdir(parents=True,exist_ok=False)
    start=time.monotonic();central=C.new_agent(seed);clients=[C.new_agent(seed+i) for i in range(3)];envs=C.make_client_envs(seed+2305000000)
    if domain=='MRO':envs=[filter_mro(e,indices[domain]['train']) for e in envs]
    probe=C.new_agent(seed+777);g=central.params();agg=Fed(seed=seed)
    losses=[];update_count=0
    # Intercept only returned loss scalars; the original train_local/update code runs unchanged.
    def attach(agent):
     original=agent.update
     def traced(*args,**kwargs):
      nonlocal update_count
      value=original(*args,**kwargs);losses.append(float(value));update_count+=1;return value
     agent.update=traced
    for a in [central]+clients:attach(a)
    events=Events(W/'TENSORBOARD'/job);curve=[]
    for rnd in range(p['rounds']+1):
     if rnd in p['curve_rounds']:
      probe.set_params(g);train=scores(*[data[domain]['train'][1],probs(probe,data[domain]['train'][0])]);val=scores(data[domain]['validation'][1],probs(probe,data[domain]['validation'][0]))
      values={'train/reference_action_cross_entropy':train['NLL'],'validation/reference_action_cross_entropy':val['NLL'],'train/accuracy':train['accuracy'],'validation/accuracy':val['accuracy']}
      if losses:values['train/ppo_actor_critic_objective']=float(np.mean(losses))
      events.add(rnd,values);np.savez(folder/f'checkpoint_{rnd:02d}.npz',**g)
      curve.append(dict(round=rnd,values=values,optimizer_calls=update_count))
      put(W/'LIVE.json',dict(utc=utc(),stage='TRAINING',running=True,job=job,round=rnd,completed_jobs=len(alljobs),total_jobs=30),True)
     if rnd==p['rounds']:break
     losses.clear()
     if method=='central_PPO':
      for e in envs:C.train_local(e,central)
      g=central.params()
     else:
      for c in clients:c.set_params(g)
      for e,c in zip(envs,clients):C.train_local(e,c)
      g=agg.aggregate([c.params() for c in clients])
    events.close();put(folder/'TRAINING.json',dict(utc=utc(),job=job,domain=domain,method=method,seed=seed,rounds=p['rounds'],optimizer_calls=update_count,training_decisions=p['decisions_per_model'],runtime_s=time.monotonic()-start,curve=curve,test_used=False))
    alljobs.append(job);print(job,round(time.monotonic()-start,2),'s',flush=True)
 put(W/'ALL_TRAINING_FROZEN_BEFORE_TEST.json',dict(utc=utc(),completed_jobs=alljobs,models=30,all_final_rounds_fixed=32,checkpoint_SHA256={str(q.relative_to(W)):sha(q) for q in (W/'RUNS').glob('*/checkpoint_*.npz')},test_forward_calls_so_far=0))
 # Test data are evaluated only after the complete training batch is frozen.
 for job in alljobs:
  info=read(W/'RUNS'/job/'TRAINING.json');C=configs[info['domain']];a=C.new_agent(0);X,y=data[info['domain']]['test'];curve=[]
  events=Events(W/'TENSORBOARD'/(job+'_posttraining_test'))
  for rnd in p['curve_rounds']:
   with np.load(W/'RUNS'/job/f'checkpoint_{rnd:02d}.npz') as z:a.set_params(dict(z))
   prob=probs(a,X);s=scores(y,prob);events.add(rnd,{'test_posttraining/accuracy':s['accuracy'],'test_posttraining/reference_action_cross_entropy':s['NLL']});curve.append(dict(round=rnd,**s))
   if rnd==p['rounds']:np.savez_compressed(W/'RUNS'/job/'FINAL_TEST_SCORES.npz',y=y,probabilities=prob)
  events.close();put(W/'RUNS'/job/'TEST_CURVE.json',dict(utc=utc(),test_after_all_training=True,curve=curve))
 assert all(sha(x['source'])==x['SHA256']==sha(x['snapshot']) for x in p['sources'])
 put(W/'EXIT.json',dict(utc=utc(),exit_code=0,stage='BOUNDED_STUDY_FINISHED',models=30,total_optimizer_calls=30*32*3*6,total_training_decisions=30*p['decisions_per_model'],wall_s=time.monotonic()-begin,old_sources_unchanged=True,old_results_changed=False,validation_and_test_separate=True))
 put(W/'LIVE.json',dict(utc=utc(),stage='FINISHED_PENDING_INDEPENDENT_READBACK',running=False,models=30),True)
if __name__=='__main__':
 if '--prepare' in sys.argv:prepare()
 else:
  try:production()
  except BaseException:
   put(W/'ERROR.json',dict(utc=utc(),traceback=__import__('traceback').format_exc(),no_silent_retry=True));raise
